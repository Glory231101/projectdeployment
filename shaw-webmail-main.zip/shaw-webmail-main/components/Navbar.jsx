import { NAV_ITEMS } from '@/utils/data';
import Link from 'next/link';
import React from 'react';
import { TbMessageCircle } from 'react-icons/tb';

export default function Navbar() {
  return (
    <nav className='bg-white'>
      <div className='w-full max-w-[90%] mx-auto py-4 bg-white flex items-center justify-between'>
        <div className='flex items-center gap-2 w-fit bg-white'>
          <div className='nav-tabs'>
            <button>Personal</button>
            <button>Business</button>
          </div>
          <div className='flex items-center max-md:hidden divide-x divide-black'>
            {NAV_ITEMS.map((item, index) => (
              <Link
                href={item.href}
                className='text-sky-600 text-xs px-2'
                key={index}
              >
                {item.name}
              </Link>
            ))}
          </div>
        </div>
        <button className='flex items-end max-md:hidden gap-2 text-sky-600'>
          <TbMessageCircle className='text-xl' />
          <p className='text-xs'>Contact</p>
        </button>
      </div>
    </nav>
  );
}
