export const NAV_ITEMS = [
    {
        name: 'Shop',
        href: '/'
    },
    {
        name: 'Support',
        href: '/'
    },
    {
        name: 'My Shaw',
        href: '/'
    },
]
