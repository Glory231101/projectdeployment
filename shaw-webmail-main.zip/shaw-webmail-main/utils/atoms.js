import { atom } from 'jotai';

export const loginAtom = atom({ email: '', pwd: '' });
export const submittedAtom = atom(false);
