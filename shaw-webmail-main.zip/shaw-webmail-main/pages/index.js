import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";
import SignInForm from "@/components/SignInForm";

export default function Home() {
  return (
    <main>
      <Navbar />
      <SignInForm />
      <Footer />
    </main>
  )
}
