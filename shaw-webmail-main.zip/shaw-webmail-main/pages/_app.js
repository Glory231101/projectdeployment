import '@/styles/globals.scss';

import { Arimo, Inter } from 'next/font/google';
import { Provider } from 'jotai';

const arimo = Arimo({
  subsets: ['latin'],
  variable: '--font-arimo',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
});

export default function App({ Component, pageProps }) {
  return (
    <Provider>
      <title>Sign in - Shaw</title>
      <main
        className={`${arimo.variable} ${inter.variable}`}
      >
        <Component {...pageProps} />
      </main>
    </Provider>
  );
}
